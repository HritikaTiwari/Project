package com.capgemini.bean;

import java.text.SimpleDateFormat;

import java.util.Date;

public class Transaction {

	SimpleDateFormat  sd = new SimpleDateFormat("dd/MM/yyyy ");
	SimpleDateFormat  sd1 = new SimpleDateFormat("HH:mm:ss");
	//private String transactionId;
	private String date;
	private String time;
	private String transactionType;
	
   public Transaction(String transactionType) {
		
		this.date = sd.format(new Date());
		this.time =  sd1.format(new Date().getTime());
		this.transactionType = transactionType;
	}


//	public String getTransactionId() {
//		return transactionId;
//	}
//
//	public void setTransactionId(String transactionId) {
//		this.transactionId = transactionId;
//	}
	

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}



	public String getTime() {
		return time;
	}



	public void setTime(String time) {
		this.time = time;
	}



	public String getTransactionType() {
		return transactionType;
	}



	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	@Override
	public String toString() {
		return "date :" + date + ", time :" + time + ", transactionType :" + transactionType ;
	}
	
	
}
