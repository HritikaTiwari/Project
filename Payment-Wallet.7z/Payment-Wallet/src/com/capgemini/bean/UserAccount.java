package com.capgemini.bean;

public class UserAccount {

	private String accountId;
	private String password;
	private String firstName;
	private String lastName;
	private double balance;
//	private double amount;
	
	public UserAccount( String password, String firstName, String lastName,double amt) {
	
		//this.accountId = accountId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = amt;
	
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
//	public double getAmount() {
//		return amount;
//	}
//	public void setAmount(double amount) {
//		this.amount = amount;
//	}
	@Override
	public String toString() {
		return "Account Id :" + accountId + ", First Name :" + firstName
				+ ",Last Name :" + lastName ;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	
	
}
