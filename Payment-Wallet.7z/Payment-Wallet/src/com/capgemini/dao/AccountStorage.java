package com.capgemini.dao;


import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

import com.capgemini.bean.UserAccount;

public class AccountStorage implements AccountStorageI{
	
	TransactionStorageI trans = new TransactionStorage();
	Random random = new Random();
	String accountId;
	UserAccount a1;
	HashMap<String,UserAccount> account = new HashMap<String,UserAccount>();

	@Override
	public String createAccount(UserAccount a) {
		// TODO Auto-generated method stub
		
	 	accountId = Long.toString(generateRandomIntIntRange(111111, 200000));
	 
	 	while(account.containsKey(accountId)==true)
	 	{
	 		accountId = Long.toString(random.nextLong());
	 		
	 	}
	 	a.setAccountId(accountId);
 		account.put(accountId, a);
 		if(account.containsKey(accountId))
 			System.out.println("Account created successfully");
	 	return accountId;
	}

	@Override
	public double showBalance() {
		// TODO Auto-generated method stub
		 a1=account.get(accountId);
		
		return a1.getBalance();
	}

	@Override
	public double deposit(double amt) {
		// TODO Auto-generated method stub
		a1=account.get(accountId);
		a1.setBalance(a1.getBalance()+amt);
	
		trans.makeTransaction("deposit");
		return a1.getBalance();
		
	}

	@Override
	public double withdraw(double amt) {
		// TODO Auto-generated method stub
		a1=account.get(accountId);
		if(a1.getBalance()> amt)
		{
			a1.setBalance(a1.getBalance()-amt);
		}
		else
		{
			System.out.println("Insufficient balance");
		}
		trans.makeTransaction("withdraw");
		return a1.getBalance();
	}

	@Override
	public double fundTransfer(String accountId1,double amt) {
		// TODO Auto-generated method stub
		  double balance ;
		     if(account.containsKey(accountId1)==true)
		     { 
		       balance = withdraw(amt);
		       a1=account.get(accountId1);
			   a1.setBalance(a1.getBalance()+amt);
		     }
		     else
		     {
		    	balance =0.0;
		     }
		     trans.makeTransaction("Fund Transfer");
		return balance;
	}

	@Override
	public void printTransaction() {
		// TODO Auto-generated method stub
		
		Set transaction = trans.getTransactions(accountId);
		 Iterator itr1 = transaction.iterator();
			while(itr1.hasNext())
			{
				Object name=itr1.next();
				System.out.println(name);
				
			}
	}

	@Override
	public boolean authenticateUser(String accountId, String pwd) {
		// TODO Auto-generated method stub
		
		if(account.containsKey(accountId))
	 	{
			a1=account.get(accountId);
			if(a1.getPassword().equals(pwd))
			{
				this.accountId=accountId;
				return true;
			}
			else
			{	return false;}
	 		
	 	}
		
		return false;
	}
	
	
	public String validateUser(UserAccount a)
	{
		if(a.getFirstName().equals(null) || a.getLastName().equals(null))
			return "customer name should not be blank";
		else if(a.getPassword().equals(null))
		    return "Password should not be blank";
		return null;
		
	}
	
	public  int generateRandomIntIntRange(int min, int max) {
	    Random r = new Random();
	    return r.nextInt((max - min) + 1) + min;
	}

}
