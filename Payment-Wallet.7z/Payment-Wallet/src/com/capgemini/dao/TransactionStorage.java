package com.capgemini.dao;


import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.capgemini.bean.Transaction;

public class TransactionStorage implements TransactionStorageI {
	
	Transaction t1;
	HashMap<String,HashSet> transaction = new HashMap<String,HashSet>();
	
	 HashSet  transactions=new HashSet(); 
	 
	 public void makeTransaction(String transactionType) 
	 {
	    t1 = new Transaction(transactionType);
	    transactions.add(t1);
	 }

	@Override
	public void storeTransactions(String accountId,HashSet transactions) {
		// TODO Auto-generated method stub
	    transaction.put(accountId,transactions);
	}

	@Override
	public Set getTransactions(String accountId) {
		
		// TODO Auto-generated method stub
		storeTransactions(accountId,transactions);
		//System.out.println);
		return transaction.get(accountId);
	}

	
	
	
}
