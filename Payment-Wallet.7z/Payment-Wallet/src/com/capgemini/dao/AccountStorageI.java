package com.capgemini.dao;

import com.capgemini.bean.UserAccount;

public interface AccountStorageI {

	String createAccount(UserAccount a);
    double showBalance();
    double deposit(double amt);
	double withdraw(double amt);
	double fundTransfer(String accountId1,double amt);
    void printTransaction();
  
	boolean authenticateUser(String accountId, String pwd);
	
}
