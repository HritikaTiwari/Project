package com.capgemini.dao;


import java.util.HashSet;
import java.util.Set;


public interface TransactionStorageI {
	
	 void storeTransactions(String accountId,HashSet transactions);
	 void makeTransaction(String transactionType) ;
	 Set getTransactions(String accountId);

}
