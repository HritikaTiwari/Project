package com.capgemini.services;

import com.capgemini.bean.UserAccount;
import com.capgemini.dao.AccountStorage;
import com.capgemini.exceptions.InvalidAmountException;

public class AccountService implements AccountServiceI {
	
	AccountStorage accountService = new AccountStorage();
	private void validateAmount(double amount) throws InvalidAmountException
	{
		if(amount <= 0)
		{
			throw new InvalidAmountException("Please enter a valid amount");
		}
		
	}

	@Override
	public String createAccount(UserAccount a) {
		// TODO Auto-generated method stub
		return accountService.createAccount(a);
	}

	@Override
	public double showBalance() {
		// TODO Auto-generated method stub
		
		return accountService.showBalance();
	}

	@Override
	public double deposit(double amt) throws InvalidAmountException {
		validateAmount(amt);
		return accountService.deposit(amt);
	}

	@Override
	public double withdraw(double amt) {
		// TODO Auto-generated method stub
		return accountService.withdraw(amt);
	}

	@Override
	public double fundTransfer(String accountId1, double amt) {
		// TODO Auto-generated method stub
		return accountService.fundTransfer(accountId1, amt);
	}

	@Override
	public void printTransaction() {
		// TODO Auto-generated method stub
		accountService.printTransaction();
		
	}

	@Override
	public boolean authenticateUser(String accountId, String pwd) {
		// TODO Auto-generated method stub
		return  accountService.authenticateUser(accountId, pwd);
		
	}

}
