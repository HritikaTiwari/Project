package com.capgemini.services;

import com.capgemini.bean.UserAccount;
import com.capgemini.exceptions.InvalidAmountException;

public interface AccountServiceI {

	String createAccount(UserAccount a);
    double showBalance();
    double deposit(double amt) throws InvalidAmountException;
	double withdraw(double amt);
	double fundTransfer(String accountId1,double amt);
    void printTransaction();
	//boolean validateUser(String accountId,String pwd);
	boolean authenticateUser(String accountId, String pwd);
	
}
