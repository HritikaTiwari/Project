package com.capgemini.services;

import java.util.HashSet;
import java.util.Set;

import com.capgemini.dao.TransactionStorage;

public class TransactionService implements TransactionServiceI {
	
	TransactionStorage transactionService = new TransactionStorage();

	@Override
	public void storeTransactions(String accountId, HashSet transactions) {
		// TODO Auto-generated method stub
		
		transactionService.storeTransactions(accountId, transactions);
	}

	@Override
	public void makeTransaction(String transactionType) {
		// TODO Auto-generated method stub
		transactionService.makeTransaction(transactionType);
	}

	@Override
	public Set getTransactions(String accountId) {
		// TODO Auto-generated method stub
		return transactionService.getTransactions(accountId);
	}

}
