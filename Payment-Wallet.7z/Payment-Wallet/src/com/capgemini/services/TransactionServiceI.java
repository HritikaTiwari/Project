package com.capgemini.services;

import java.util.HashSet;
import java.util.Set;

public interface TransactionServiceI {

	 void storeTransactions(String accountId,HashSet transactions);
	 void makeTransaction(String transactionType) ;
	 Set getTransactions(String accountId);
	
}
