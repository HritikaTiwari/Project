package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.bean.UserAccount;
import com.capgemini.exceptions.InvalidAmountException;
import com.capgemini.services.AccountService;

public class UserAccountUI {

	public static void showHomePage() {
		System.out.println("Please enter respective number for selecting operation:");
		System.out.println("1. Sign Up");
		System.out.println("2. Create Account");

	}

	public static void showServices() {
		System.out.println("Please enter respective number for selecting operation:");
		System.out.println("1. Deposit");
		System.out.println("2. Withdraw");
		System.out.println("3. Fund Transfer");
		System.out.println("4. Balance Details");
		System.out.println("5. Transaction Details");

	}

	public static void main(String[] args) {

		AccountService service = new AccountService();

		boolean exitApplication = false;
		do {
			showHomePage();
			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter the account number. :");
				String accountId = sc.next();
				System.out.println("Enter the account password :");
				String pwd = sc.next();
				if (service.authenticateUser(accountId, pwd)) {
					boolean gotodashboard = false;
					do {
						showServices();
						int option1 = sc.nextInt();
						switch (option1) {
						case 1:
							try {
										System.out.println("Enter the amount :");
							double amt = sc.nextDouble();
							System.out.println(service.deposit(amt));
							}catch(InvalidAmountException e)
							{
								System.out.println(e.getMessage());
							}
							catch(Exception e)
							{
								System.out.println("something went wrong!");
							}
							break;
						case 2:
							System.out.println("Enter the amount :");
							double amt1 = sc.nextDouble();
							System.out.println(service.withdraw(amt1));
							break;
						case 3:
							System.out.println("Enter the amount :");
							double amt2 = sc.nextDouble();
							System.out.println("Enter the receiver account number :");
							String accountId1 = sc.next();
							System.out.println(service.fundTransfer(accountId1, amt2));
							break;
						case 4:
							System.out.println(service.showBalance());
							break;
						case 5:
							service.printTransaction();
							break;
						case 6:
							gotodashboard = true;
							break;
						default:
							System.out.println("invalid input");
							break;

						}
					} while (!gotodashboard);
				} else {
					System.out.println("Please enter valid account number and password");
				}
				break;
			case 2:

				System.out.println("Enter the customer first name :");
				String fname = sc.next();
				System.out.println("Enter the customer last name :");
				String lname = sc.next();
				System.out.println("Enter the password. :");
				String password = sc.next();
				System.out.println("Enter the amount to deposit :");
				double amount = sc.nextDouble();

				UserAccount customer = new UserAccount(password, fname, lname, amount);
				System.out.println("Your Account No. :" + service.createAccount(customer));
				break;

			case 3:
				exitApplication = true;
				break;
			default:
				System.out.println("invalid input");
			}
		} while (!exitApplication);

	}
}
